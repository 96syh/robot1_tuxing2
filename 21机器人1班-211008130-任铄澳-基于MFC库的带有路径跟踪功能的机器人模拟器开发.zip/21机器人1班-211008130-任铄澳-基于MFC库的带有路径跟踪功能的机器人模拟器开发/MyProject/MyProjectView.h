
// MyProjectView.h : CMyProjectView ��Ľӿ�
//

#pragma once

#include <vector>
using namespace std;


class CMyProjectView : public CView
{
protected: // �������л�����
	CMyProjectView();
	DECLARE_DYNCREATE(CMyProjectView)

// ����
public:
	CMyProjectDoc* GetDocument() const;

// ����
public:

// ��д
public:
	virtual void OnDraw(CDC* pDC);  // ��д�Ի��Ƹ���ͼ
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// ʵ��
public:
	virtual ~CMyProjectView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnMenuStart();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);

private:
	BOOL m_bDraw;
	CPoint m_LastPoint;
	vector<CPoint> m_vecPoint;
	BOOL m_bMove;	// �������Ƿ��ƶ�
	int m_nIdx;	// �����˵�ǰ�ߵ��ĵ�
};

#ifndef _DEBUG  // MyProjectView.cpp �еĵ��԰汾
inline CMyProjectDoc* CMyProjectView::GetDocument() const
   { return reinterpret_cast<CMyProjectDoc*>(m_pDocument); }
#endif

